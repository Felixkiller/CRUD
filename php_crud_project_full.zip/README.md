# PHP CRUD Project (Single File with Composer)

This is a simple PHP CRUD (Create, Read, Update, Delete) application using PDO and Composer autoloading.

## Features
- Add new users
- Edit existing users
- Delete users
- View all users

## Setup Instructions

1. Import the `database.sql` into your MySQL server to create the `users` table.
2. Update your database credentials in `index.php`.
3. Run `composer install` to generate the `vendor/` directory.
4. Place the project in your web server directory (e.g., `htdocs` or `public_html`).
5. Access via your browser.

## Note
- This is a minimal example and doesn't include CSRF protection or validation.
