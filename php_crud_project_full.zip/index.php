<?php
require __DIR__ . '/vendor/autoload.php';

// === DB CONFIG ===
$dbHost = 'localhost';
$dbName = 'your_database';
$dbUser = 'root';
$dbPass = '';

try {
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("DB connection failed: " . $e->getMessage());
}

$action = $_GET['action'] ?? null;

// === CREATE ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'create') {
    $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, bio) VALUES (?, ?, ?, ?)");
    $stmt->execute([
        $_POST['name'],
        $_POST['email'],
        $_POST['phone'] !== '' ? $_POST['phone'] : null,
        $_POST['bio'] !== '' ? $_POST['bio'] : null
    ]);
    header("Location: index.php");
    exit;
}

// === DELETE ===
if ($action === 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    header("Location: index.php");
    exit;
}

// === UPDATE ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ?, bio = ? WHERE id = ?");
    $stmt->execute([
        $_POST['name'],
        $_POST['email'],
        $_POST['phone'] !== '' ? $_POST['phone'] : null,
        $_POST['bio'] !== '' ? $_POST['bio'] : null,
        $_GET['id']
    ]);
    header("Location: index.php");
    exit;
}

// === FETCH USERS ===
$users = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

// === FETCH USER FOR EDIT ===
$editUser = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $editUser = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>PHP CRUD (Single File with Composer)</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        input, textarea, button { display: block; margin: 8px 0; width: 300px; }
        table { border-collapse: collapse; margin-top: 20px; width: 100%; }
        th, td { padding: 10px; border: 1px solid #ccc; }
    </style>
</head>
<body>

<h2><?= $editUser ? 'Edit User' : 'Create User' ?></h2>

<form method="POST" action="?action=<?= $editUser ? 'update&id=' . $editUser['id'] : 'create' ?>">
    <input type="text" name="name" placeholder="Name" required value="<?= $editUser['name'] ?? '' ?>">
    <input type="email" name="email" placeholder="Email" required value="<?= $editUser['email'] ?? '' ?>">
    <input type="text" name="phone" placeholder="Phone (optional)" value="<?= $editUser['phone'] ?? '' ?>">
    <textarea name="bio" placeholder="Bio (optional)"><?= $editUser['bio'] ?? '' ?></textarea>
    <button type="submit"><?= $editUser ? 'Update' : 'Create' ?></button>
    <?php if ($editUser): ?>
        <a href="index.php">Cancel</a>
    <?php endif; ?>
</form>

<h3>User List</h3>
<table>
    <tr>
        <th>Name</th><th>Email</th><th>Phone</th><th>Bio</th><th>Actions</th>
    </tr>
    <?php foreach ($users as $user): ?>
        <tr>
            <td><?= htmlspecialchars($user['name']) ?></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
            <td><?= $user['phone'] ?? '<i>none</i>' ?></td>
            <td><?= $user['bio'] ?? '<i>none</i>' ?></td>
            <td>
                <a href="?action=edit&id=<?= $user['id'] ?>">Edit</a> |
                <a href="?action=delete&id=<?= $user['id'] ?>" onclick="return confirm('Delete this user?')">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
